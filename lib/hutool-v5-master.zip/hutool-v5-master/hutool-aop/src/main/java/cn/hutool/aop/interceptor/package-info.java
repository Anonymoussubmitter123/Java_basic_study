/**
 * 代理拦截器实现
 *
 * @author looly
 *
 */
package cn.hutool.aop.interceptor;