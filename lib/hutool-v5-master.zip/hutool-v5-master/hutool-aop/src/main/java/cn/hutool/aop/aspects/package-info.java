/**
 * 切面实现，提供一些基本的切面实现
 *
 * @author looly
 *
 */
package cn.hutool.aop.aspects;