/**
 * BitMap实现
 *
 * @author looly
 *
 */
package cn.hutool.bloomfilter.bitMap;