/**
 * 验证码生成策略实现
 *
 * @author looly
 * @since 4.1.2
 */
package cn.hutool.captcha.generator;