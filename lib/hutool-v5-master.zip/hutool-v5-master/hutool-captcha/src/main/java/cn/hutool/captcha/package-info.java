/**
 * 图片验证码实现
 *
 * @author looly
 *
 */
package cn.hutool.captcha;