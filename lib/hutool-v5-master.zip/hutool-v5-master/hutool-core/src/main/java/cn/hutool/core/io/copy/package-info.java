/**
 * IO流拷贝相关封装相关封装
 *
 * @author looly
 * @since 5.7.8
 */
package cn.hutool.core.io.copy;
