/**
 * 克隆封装
 *
 * @author looly
 *
 */
package cn.hutool.core.clone;