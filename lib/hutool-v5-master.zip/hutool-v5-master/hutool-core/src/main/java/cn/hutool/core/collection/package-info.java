/**
 * 集合以及Iterator封装，包括集合工具CollUtil，Iterator和Iterable工具IterUtil
 *
 * @author looly
 *
 */
package cn.hutool.core.collection;