/**
 * IO校验相关库和工具
 *
 * @author looly
 *
 */
package cn.hutool.core.io.checksum;