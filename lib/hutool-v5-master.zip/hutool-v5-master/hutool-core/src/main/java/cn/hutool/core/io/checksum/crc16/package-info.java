/**
 * CRC16相关算法封装为Checksum
 *
 * @author looly
 *
 */
package cn.hutool.core.io.checksum.crc16;