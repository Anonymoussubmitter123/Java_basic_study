# Security Policy

## Supported Versions（支持的版本）

| Version | Supported          |
| ------- | ------------------ |
| 5.x.x   | :white_check_mark: |
| 4.x.x   | :x:                |
| 3.x.x   | :x:                |

## Reporting a Vulnerability（报告漏洞）

如果你发现有安全问题或漏洞，请发送邮件到`loolly@aliyun.com`。

To report any found security issues or vulnerabilities, please send a mail to `loolly@aliyun.com`.